def say_hello():
    """Prints a Hello, World! message."""
    return "Hello, World!"
